import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/error/failures.dart';
import '../../../../core/router/route_names.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../shared/widgets/app_badge.dart';
import '../../../../shared/widgets/app_button.dart';
import '../../../../shared/widgets/app_snack.dart';
import '../../../../shared/widgets/bottom_action_bar.dart';
import '../../../../shared/widgets/detail_top_bar.dart';
import '../../../../shared/widgets/info_banner.dart';
import '../../../../shared/widgets/state_views.dart';
import '../../domain/entities/ride.dart';
import '../providers/carpool_providers.dart';
import 'new_ride_page.dart';
import '../widgets/booking_requests_card.dart';
import '../widgets/driver_card.dart';
import '../widgets/ride_summary_card.dart';
import '../widgets/route_map_preview.dart';
import '../widgets/seat_picker.dart';

/// "Ride Detail & Booking" screen.
class RideDetailPage extends ConsumerStatefulWidget {
  const RideDetailPage({super.key, required this.rideId});

  final String rideId;

  @override
  ConsumerState<RideDetailPage> createState() => _RideDetailPageState();
}

class _RideDetailPageState extends ConsumerState<RideDetailPage> {
  /// null = user has not touched the seats yet -> first free seat is preselected.
  Set<String>? _picked;
  bool _reserving = false;
  bool _busy = false; // the driver is editing, deleting or cancelling

  Set<String> _selection(Ride ride) {
    // The driver can't book a seat in their own ride.
    if (ride.isMine) return const {};
    final free = ride.freeSeats.map((s) => s.id).toSet();
    final base = _picked ?? (free.isEmpty ? <String>{} : {free.first});
    return base.where(free.contains).toSet();
  }

  void _toggle(Ride ride, String seatId) {
    final current = {..._selection(ride)};
    if (current.contains(seatId)) {
      current.remove(seatId);
    } else {
      current.add(seatId);
    }
    setState(() => _picked = current);
  }

  void _snack(String message) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));

  Future<void> _reserve(Ride ride) async {
    final seatIds = _selection(ride).toList();
    setState(() => _reserving = true);
    final result = await ref
        .read(carpoolRepositoryProvider)
        .reserveSeats(rideId: ride.id, seatIds: seatIds);
    if (!mounted) return;
    setState(() => _reserving = false);

    result.when(
      success: (updated) {
        setState(() => _picked = <String>{});
        ref.invalidate(rideDetailProvider(ride.id));
        ref.invalidate(ridesProvider);
        ref.invalidate(myBookingsProvider);
        _snack(
          updated.hasMyPendingRequest
              ? 'Request sent. The driver will answer soon.'
              : 'Seat reserved. See you on board!',
        );
      },
      failure: (f) => _snack(f.message),
    );
  }

  // ---- Driver actions (own ride only) ----

  Future<bool> _confirm({
    required String title,
    required String message,
    required String confirmLabel,
  }) async {
    final scheme = Theme.of(context).colorScheme;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            style: TextButton.styleFrom(minimumSize: const Size(0, 40)),
            child: const Text('Keep'),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            style: TextButton.styleFrom(
              minimumSize: const Size(0, 40),
              foregroundColor: scheme.error,
            ),
            child: Text(confirmLabel),
          ),
        ],
      ),
    );
    return ok ?? false;
  }

  Future<void> _edit(Ride ride) async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => NewRidePage(editing: ride)),
    );
    if (saved != true || !mounted) return;
    setState(() => _picked = null);
    ref.invalidate(rideDetailProvider(ride.id));
    ref.invalidate(ridesProvider);
  }

  Future<void> _delete(Ride ride) async {
    final ok = await _confirm(
      title: 'Delete this ride?',
      message: 'Ride ${ride.code} will disappear for every student, and the '
          'seats already booked are cancelled. This cannot be undone.',
      confirmLabel: 'Delete',
    );
    if (!ok || !mounted) return;

    setState(() => _busy = true);
    final result = await ref.read(carpoolRepositoryProvider).deleteRide(ride.id);
    if (!mounted) return;
    setState(() => _busy = false);

    result.when(
      success: (_) {
        // Not the detail provider: the ride no longer exists, refetching it would fail.
        ref.invalidate(ridesProvider);
        showAppSnack(context, 'Ride deleted.');
        if (context.canPop()) {
          context.pop();
        } else {
          context.go(RoutePaths.forum);
        }
      },
      failure: (f) => _snack(f.message),
    );
  }

  Future<void> _cancelBooking(Ride ride, Seat seat) async {
    final ok = await _confirm(
      title: 'Cancel this booking?',
      message: seat.isMine
          ? 'Your seat becomes free again for other students.'
          : '${seat.label} will lose their seat, and it becomes free again '
              'for other students.',
      confirmLabel: 'Cancel booking',
    );
    if (!ok || !mounted) return;

    setState(() => _busy = true);
    final result = await ref
        .read(carpoolRepositoryProvider)
        .cancelReservation(rideId: ride.id, seatId: seat.id);
    if (!mounted) return;
    setState(() => _busy = false);

    result.when(
      success: (_) {
        ref.invalidate(rideDetailProvider(ride.id));
        ref.invalidate(ridesProvider);
        ref.invalidate(myBookingsProvider);
        _snack('Booking cancelled. The seat is free again.');
      },
      failure: (f) => _snack(f.message),
    );
  }

  Future<void> _answer(Ride ride, Seat seat, {required bool accept}) async {
    setState(() => _busy = true);
    final repo = ref.read(carpoolRepositoryProvider);
    final result = accept
        ? await repo.acceptReservation(rideId: ride.id, seatId: seat.id)
        : await repo.refuseReservation(rideId: ride.id, seatId: seat.id);
    if (!mounted) return;
    setState(() => _busy = false);

    result.when(
      success: (_) {
        ref.invalidate(rideDetailProvider(ride.id));
        ref.invalidate(ridesProvider);
        _snack(accept ? '${seat.label} is confirmed.' : 'Request refused. The seat is free again.');
      },
      failure: (f) => _snack(f.message),
    );
  }

  /// The student cancels everything they booked or asked for in this ride.
  Future<void> _cancelMyBooking(Ride ride) async {
    final ok = await _confirm(
      title: ride.hasMyPendingRequest ? 'Withdraw your request?' : 'Cancel your booking?',
      message: 'Your seat${ride.mySeats.length == 1 ? '' : 's'} will be free again '
          'for other students.',
      confirmLabel: ride.hasMyPendingRequest ? 'Withdraw' : 'Cancel booking',
    );
    if (!ok || !mounted) return;

    setState(() => _busy = true);
    final repo = ref.read(carpoolRepositoryProvider);
    String? error;
    for (final seat in ride.mySeats) {
      final result = await repo.cancelReservation(rideId: ride.id, seatId: seat.id);
      error = result.when(success: (_) => null, failure: (f) => f.message);
      if (error != null) break;
    }
    if (!mounted) return;
    setState(() => _busy = false);
    ref.invalidate(rideDetailProvider(ride.id));
    ref.invalidate(ridesProvider);
    ref.invalidate(myBookingsProvider);
    _snack(error ?? 'Booking cancelled.');
  }

  /// What the student's own booking looks like in this ride.
  Widget _myBookingBanner(Ride ride) {
    final pending = ride.mySeats.where((s) => s.status == SeatStatus.pending).length;
    final booked = ride.mySeats.length - pending;
    final String title;
    final String message;
    if (pending > 0 && booked == 0) {
      title = 'Request sent';
      message = 'Waiting for the driver to accept. You can cancel until then.';
    } else if (pending == 0) {
      title = 'Booking confirmed';
      message = 'The driver accepted your '
          '${booked == 1 ? 'seat' : '$booked seats'}. See you on board!';
    } else {
      title = 'Your booking';
      message = '$booked confirmed · $pending waiting for the driver.';
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        InfoBanner(
          icon: pending > 0 ? Icons.hourglass_top_rounded : Icons.check_circle_outline,
          tone: pending > 0 ? BadgeTone.accent : BadgeTone.success,
          title: title,
          message: message,
        ),
        Align(
          alignment: Alignment.centerRight,
          child: TextButton.icon(
            onPressed: _busy ? null : () => _cancelMyBooking(ride),
            icon: const Icon(Icons.close_rounded),
            label: Text(pending > 0 && booked == 0 ? 'Withdraw request' : 'Cancel booking'),
            style: TextButton.styleFrom(
              minimumSize: const Size(0, 40),
              foregroundColor: Theme.of(context).colorScheme.error,
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.sm),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(rideDetailProvider(widget.rideId));
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: async.when(
          skipLoadingOnReload: true,
          loading: () => const LoadingView(),
          error: (e, _) => ErrorView(
            message: failureMessage(e),
            onRetry: () => ref.invalidate(rideDetailProvider(widget.rideId)),
          ),
          data: _buildContent,
        ),
      ),
    );
  }

  Widget _buildContent(Ride ride) {
    final selected = _selection(ride);
    final count = selected.length;
    final theme = Theme.of(context);

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: EdgeInsets.fromLTRB(
              AppSpacing.page,
              AppSpacing.md,
              AppSpacing.page,
              // Without the booking bar, keep clear of the system bar.
              AppSpacing.lg,
            ),
            children: [
              DetailTopBar(
                backLabel: 'Back to Forum',
                fallbackPath: RoutePaths.forum,
                trailing: [
                  // Flexible: ellipsized rather than overflowing with large text.
                  Flexible(child: AppBadge('RIDE #${ride.code}', tone: BadgeTone.neutral)),
                ],
              ),
              const SizedBox(height: AppSpacing.lg),
              RouteMapPreview(ride: ride),
              const SizedBox(height: AppSpacing.md),
              RideSummaryCard(ride: ride),
              const SizedBox(height: AppSpacing.md),
              DriverCard(driver: ride.driver, amenities: ride.amenities),
              const SizedBox(height: AppSpacing.md),
              if (ride.isMine) ...[
                const InfoBanner(
                  icon: Icons.drive_eta_outlined,
                  tone: BadgeTone.success,
                  title: "You're driving this ride",
                  message: 'Students ask for your free seats from here and you accept or '
                      'refuse each request. You can also edit or delete the ride below.',
                ),
                const SizedBox(height: AppSpacing.md),
                if (ride.pendingSeats.isNotEmpty) ...[
                  BookingRequestsCard(
                    requests: ride.pendingSeats,
                    busy: _busy,
                    onAccept: (seat) => _answer(ride, seat, accept: true),
                    onRefuse: (seat) => _answer(ride, seat, accept: false),
                  ),
                  const SizedBox(height: AppSpacing.md),
                ],
              ] else if (ride.hasMyBooking)
                _myBookingBanner(ride),
              SeatPicker(
                seats: ride.seats,
                selected: selected,
                enabled: !ride.isMine,
                onToggle: (id) => _toggle(ride, id),
                onManageTap: _busy ? null : (seat) => _cancelBooking(ride, seat),
                // The driver cancels booked seats (pending ones are answered
                // above); a student cancels their own seats.
                isManageable: (seat) => ride.isMine
                    ? seat.status == SeatStatus.booked
                    : seat.isMine,
              ),
            ],
          ),
        ),
        if (ride.isMine)
          BottomActionBar(
            leading: TextButton.icon(
              onPressed: _busy ? null : () => _delete(ride),
              icon: const Icon(Icons.delete_outline),
              label: const Text('Delete'),
              style: TextButton.styleFrom(
                // The global button theme is full-width.
                minimumSize: const Size(0, 44),
                foregroundColor: theme.colorScheme.error,
              ),
            ),
            action: AppButton(
              label: 'Edit ride',
              icon: Icons.edit_outlined,
              variant: AppButtonVariant.accent,
              isLoading: _busy,
              onPressed: _busy ? null : () => _edit(ride),
            ),
          )
        else
          BottomActionBar(
            leading: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'TOTAL BOOKING',
                  style: theme.textTheme.labelSmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                Text(
                  '${ride.totalFor(count).toStringAsFixed(3)} TND',
                  style: theme.textTheme.titleLarge,
                ),
                Text(
                  '$count seat${count == 1 ? '' : 's'} selected',
                  style: theme.textTheme.labelSmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ],
            ),
            action: AppButton(
              label: 'Reserve Seat',
              icon: Icons.bolt,
              variant: AppButtonVariant.accent,
              isLoading: _reserving,
              onPressed: count == 0 ? null : () => _reserve(ride),
            ),
          ),
      ],
    );
  }
}
