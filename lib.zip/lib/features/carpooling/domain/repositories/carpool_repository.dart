import '../../../../core/error/result.dart';
import '../entities/carpool_impact.dart';
import '../entities/new_ride.dart';
import '../entities/ride.dart';

abstract interface class CarpoolRepository {
  Future<Result<List<Ride>>> getRides();
  Future<Result<Ride>> getRide(String id);
  Future<Result<void>> reserveSeats({required String rideId, required List<String> seatIds});
  Future<Result<CarpoolImpact>> getMonthlyImpact();

  /// Publishes [ride] with the signed-in student as its driver, and returns
  /// it as every student now sees it in [getRides].
  Future<Result<Ride>> createRide(NewRide ride);
}
